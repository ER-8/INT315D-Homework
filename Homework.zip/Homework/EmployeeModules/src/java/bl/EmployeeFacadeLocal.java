package bl;

import entities.Employee;
import java.util.List;
import javax.ejb.Local;

@Local
public interface EmployeeFacadeLocal {

    void createEmployee(Employee employee);
    void edit(Employee employee);
    void removeEmployee(Employee employee);
    Employee findEmployee(Object id);
    List<Employee> findAllEmployee();
    List<Employee> findDepartmentEmployees(String department);  
    Double getHighestPaid();
    int count();   
}
