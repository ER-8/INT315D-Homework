package bl;

import entities.Employee;
import java.util.List;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class EmployeeFacade extends AbstractFacade<Employee> implements EmployeeFacadeLocal {

    @PersistenceContext(unitName = "ClassTest5ModulesPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public EmployeeFacade() {
        super(Employee.class);
    }
    
    @RolesAllowed("secretary")
    @Override
    public void createEmployee(Employee employee) {
        create(employee);
    }
    
    @RolesAllowed("manager")
    @Override
    public void removeEmployee(Employee employee) {
        remove(employee);
    }
    
    @RolesAllowed("manager")
    @Override
    public Employee findEmployee(Object id) {
        Employee targetEmployee = find(id);
        return targetEmployee;
    }
    
    @RolesAllowed("manager")
    @Override
    public List<Employee> findAllEmployee() {
        List<Employee> list = findAll();
        return list;
    }
    
    @RolesAllowed("manager")
    @Override
    public List<Employee> findDepartmentEmployees(String department) {
        Query query = em.createQuery("SELECT e FROM Employee e WHERE e.department = :department");
        query.setParameter("department", department);
        List<Employee> employees = query.getResultList();
        return employees;
    }
    
    @RolesAllowed("manager")
    @Override
    public Double getHighestPaid() {
        Query query = em.createQuery("SELECT MAX(e.salary) FROM Employee e");
        Double maxSalary = (Double)query.getSingleResult();
        return maxSalary;    
    }
}
