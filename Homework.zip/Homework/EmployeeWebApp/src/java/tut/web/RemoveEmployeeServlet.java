package tut.web;

import bl.EmployeeFacadeLocal;
import entities.Employee;
import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RemoveEmployeeServlet extends HttpServlet {
    @EJB
    private EmployeeFacadeLocal efl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Long employeeNum = Long.parseLong(request.getParameter("id"));

        Employee employee = generateEmployee(employeeNum);
        efl.removeEmployee(employee);
        
        RequestDispatcher disp = request.getRequestDispatcher("removeemployee_outcome.jsp");
        disp.forward(request, response);
    }

    private Employee generateEmployee(Long employeeNum) {
        Employee employee = new Employee();
        employee.setId(employeeNum);
        return employee;
    }
}
