package tut.web;

import bl.EmployeeFacadeLocal;
import entities.Employee;
import java.io.IOException;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FindHighestPaidEmployeeServlet extends HttpServlet {
    @EJB
    private EmployeeFacadeLocal efl;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Double highestPaid = efl.getHighestPaid();
        List<Employee> employees = efl.findAllEmployee();
        Employee highestPaidEmployee = null;
        
        for (Employee emp : employees) {
            if (emp.getSalary().equals(highestPaid)) {
                highestPaidEmployee = emp;
                break;
            }
        }
        
        request.setAttribute("employee", highestPaidEmployee);
        
        RequestDispatcher disp = request.getRequestDispatcher("highestpaid_outcome.jsp");
        disp.forward(request, response);
    }
}
